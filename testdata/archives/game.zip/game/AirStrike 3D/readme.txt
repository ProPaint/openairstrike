Synthetic game files for the archive tests of OpenAirStrike. No game data.
